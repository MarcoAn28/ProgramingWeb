
var clase_Tablero = document.getElementById("tablero");
var Puntajes = document.getElementById("puntos");
var fondo_Negro = document.getElementById("fondo_Oscuro");
var clase_cuadro = document.getElementsByClassName("casilla");
var clase_revisaBlancos = document.getElementsByClassName("revisar_Blancos");
var clase_revisaNegros = document.getElementsByClassName("revisar_Negros");
var moveSound = document.getElementById("moveSound");
var winSound = document.getElementById("winSound");
var windowHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;  
var windowWidth =  window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
var largoMovida = 80 ;
var desviacionMovida = 10;
var Dimension = 1;
var piezaElegida,piezaElegidaindex;
var derchaArriba,izquierdaArriba,izquierdaAbajo,derechaAbajo;  
var contor = 0 , fin_de_juego = 0;
var pantalla = 1;

var bloque = [];
var revisar_FBlanco = [];
var revisar_FNegra = [];
var checador ;
var primer_Movimiento;
var otro_movimiento;
var puedeAtacar = false;
var multiplier = 1 

var clase_TableroLimit,reverse_clase_TableroLimit ,  moveizquierdaArriba,movederchaArriba,
	moveizquierdaAbajo,movederechaAbajo , clase_TableroLimitLeft, clase_TableroLimitRight;

/*======================================================================================================================================*/
	getDimension();
	if(windowWidth > 640){
		largoMovida = 80;
		desviacionMovida = 10;
	}
	else{
		largoMovida = 50;
		desviacionMovida = 6;
	}

/*========================================================================================================================================*/

var cuadro_p = function(square,index){
	this.id = square;
	this.ocupied = false;
	this.pieceId = undefined;
	this.id.onclick = function() {
		hacerCamino(index);
	}
}

var checker = function(piece,color,square) {
	this.id = piece;
	this.color = color;
	this.king = false;
	this.ocupied_square = square;
	this.alive = true;
	this.attack = false;
	if(square%8){
		this.coordX= square%8;
		this.coordY = Math.floor(square/8) + 1 ;
	}
	else{
		this.coordX = 8;
		this.coordY = square/8 ;
	}
	this.id.onclick = function  () {
		mostrar_movimientos(piece);	
	}
}

checker.prototype.setCoord = function(X,Y){
	var x = (this.coordX - 1  ) * largoMovida + desviacionMovida;
	var y = (this.coordY - 1 ) * largoMovida  + desviacionMovida;
	this.id.style.top = y + 'px';
	this.id.style.left = x + 'px';
}

checker.prototype.changeCoord = function(X,Y){
	this.coordY +=Y;
	this.coordX += X;
}

checker.prototype.checkIfKing = function () {
	if(this.coordY == 8 && !this.king &&this.color == "white"){
		this.king = true;
		this.id.style.border = "4px solid red";
		this.id.style.backgroundImage ="url('corona.jpg')";
	}
	if(this.coordY == 1 && !this.king &&this.color == "black"){
		this.king = true;
		this.id.style.border = "4px solid ";
		
		this.id.style.backgroundImage ="url('corona.jpg')";
	}
}

/*=========================================================================================================================================*/


for (var i = 1; i <=64; i++)
	bloque[i] =new cuadro_p(clase_cuadro[i],i);

/*=========================================================================================================================================*/

for (var i = 1; i <= 4; i++){
	revisar_FBlanco[i] = new checker(clase_revisaBlancos[i], "white", 2*i -1 );
	revisar_FBlanco[i].setCoord(0,0);
	bloque[2*i - 1].ocupied = true;
	bloque[2*i - 1].pieceId =revisar_FBlanco[i];
}

for (var i = 5; i <= 8; i++){
	revisar_FBlanco[i] = new checker(clase_revisaBlancos[i], "white", 2*i );
	revisar_FBlanco[i].setCoord(0,0);
	bloque[2*i].ocupied = true;
	bloque[2*i].pieceId = revisar_FBlanco[i];
}

for (var i = 9; i <= 12; i++){
	revisar_FBlanco[i] = new checker(clase_revisaBlancos[i], "white", 2*i - 1 );
	revisar_FBlanco[i].setCoord(0,0);
	bloque[2*i - 1].ocupied = true;
	bloque[2*i - 1].pieceId = revisar_FBlanco[i];
}

for (var i = 1; i <= 4; i++){
	revisar_FNegra[i] = new checker(clase_revisaNegros[i], "black", 56 + 2*i  );
	revisar_FNegra[i].setCoord(0,0);
	bloque[56 +  2*i ].ocupied = true;
	bloque[56+  2*i ].pieceId =revisar_FNegra[i];
}

for (var i = 5; i <= 8; i++){
	revisar_FNegra[i] = new checker(clase_revisaNegros[i], "black", 40 +  2*i - 1 );
	revisar_FNegra[i].setCoord(0,0);
	bloque[ 40 + 2*i - 1].ocupied = true;
	bloque[ 40 + 2*i - 1].pieceId = revisar_FNegra[i];
}

for (var i = 9; i <= 12; i++){
	revisar_FNegra[i] = new checker(clase_revisaNegros[i], "black", 24 + 2*i  );
	revisar_FNegra[i].setCoord(0,0);
	bloque[24 + 2*i ].ocupied = true;
	bloque[24 + 2*i ].pieceId = revisar_FNegra[i];
}


/*===================================================================================================================================*/
checador = revisar_FBlanco;

function mostrar_movimientos (piece) {
	
	
	var match = false;
	puedeAtacar = false;
	if(piezaElegida){
			borrarCamino(piezaElegida);
	}
	piezaElegida = piece;
	var i,j; 
	for ( j = 1; j <= 12; j++){
		if(checador[j].id == piece){
			i = j;
			piezaElegidaindex = j;
			match = true;
		}
	}

	if(primer_Movimiento && !movimientos_DAtaque(primer_Movimiento)){
		cambio_Dturnos(primer_Movimiento);
		primer_Movimiento = undefined;
		return false;
	}
	if(primer_Movimiento && primer_Movimiento != checador[i] ){
		return false;
	}

	if(!match) {
	 return 0 ;
	}

	if(checador[i].color =="white"){
		clase_TableroLimit = 8;
		clase_TableroLimitRight = 1;
		clase_TableroLimitLeft = 8;
		movederchaArriba = 7;
		moveizquierdaArriba = 9;
		movederechaAbajo = - 9;
		moveizquierdaAbajo = -7;
	}
	else{
		clase_TableroLimit = 1;
		clase_TableroLimitRight = 8;
		clase_TableroLimitLeft = 1;
		movederchaArriba = -7;
		moveizquierdaArriba = -9;
		movederechaAbajo = 9;
		moveizquierdaAbajo = 7;
	}

	movimientos_DAtaque(checador[i]); 

 	if(!puedeAtacar){
 	  izquierdaAbajo = revisarMovimiento( checador[i] , clase_TableroLimit , clase_TableroLimitRight , movederchaArriba , izquierdaAbajo);
		derechaAbajo = revisarMovimiento( checador[i] , clase_TableroLimit , clase_TableroLimitLeft , moveizquierdaArriba , derechaAbajo);
		if(checador[i].king){
			izquierdaArriba = revisarMovimiento( checador[i] , reverse_clase_TableroLimit , clase_TableroLimitRight , movederechaAbajo , izquierdaArriba);
			derchaArriba = revisarMovimiento( checador[i], reverse_clase_TableroLimit , clase_TableroLimitLeft , moveizquierdaAbajo, derchaArriba)
		}
	}
	if(izquierdaAbajo || derechaAbajo || izquierdaArriba || derchaArriba){
			return true;
		}
	return false;
	
}

/*=================================================================================================================================*/
function borrarCamino(piece){
	if(derechaAbajo) bloque[derechaAbajo].id.style.background = "#85929E";
	if(izquierdaAbajo) bloque[izquierdaAbajo].id.style.background = "#85929E";
	if(derchaArriba) bloque[derchaArriba].id.style.background = "#85929E";
	if(izquierdaArriba) bloque[izquierdaArriba].id.style.background = "#85929E";
}
		
/*=====================================================================================================================================*/


function hacerCamino (index) {
	var isMove = false;
	if(!piezaElegida) 
		return false;
	if(index != izquierdaArriba && index != derchaArriba && index != izquierdaAbajo && index != derechaAbajo){
		borrarCamino(0);
		piezaElegida = undefined;
		return false;
	}

	if(checador[1].color=="white"){
		cpy_derechaAbajo = derchaArriba;
		cpy_izquierdaAbajo = izquierdaArriba;
		cpy_izquierdaArriba = izquierdaAbajo;
		cpy_derchaArriba = derechaAbajo;
	}
	else{
		cpy_derechaAbajo = izquierdaArriba;
		cpy_izquierdaAbajo = derchaArriba;
		cpy_izquierdaArriba = derechaAbajo;
		cpy_derchaArriba = izquierdaAbajo;
	}  

	if(puedeAtacar)  
		multiplier = 2;
	else
		multiplier = 1;


		if(index == cpy_derchaArriba){
			isMove = true;		
			if(checador[1].color=="white"){
				
				ejecutarMovimiento( multiplier * 1, multiplier * 1, multiplier * 9 );
				
				if(puedeAtacar) comprobar_eliminacion(index - 9);
			}
			else{
				ejecutarMovimiento( multiplier * 1, multiplier * -1, multiplier * -7);
				if(puedeAtacar) comprobar_eliminacion( index + 7 );
			}
		}

		if(index == cpy_izquierdaArriba){
	
			isMove = true;
			if(checador[1].color=="white"){
				ejecutarMovimiento( multiplier * -1, multiplier * 1, multiplier * 7);
			 	if(puedeAtacar)	comprobar_eliminacion(index - 7 );				
			}
			else{
				ejecutarMovimiento( multiplier * -1, multiplier * -1, multiplier * -9);
				if (puedeAtacar) comprobar_eliminacion( index + 9 );
			}
		}

		if(checador[piezaElegidaindex].king){

			if(index == cpy_derechaAbajo){
				isMove = true;
				if(checador[1].color=="white"){
					ejecutarMovimiento( multiplier * 1, multiplier * -1, multiplier * -7);
					if(puedeAtacar) comprobar_eliminacion ( index  + 7) ;
				}
				else{
					ejecutarMovimiento( multiplier * 1, multiplier * 1, multiplier * 9);
					if(puedeAtacar) comprobar_eliminacion ( index  - 9) ;
				}
			}

		if(index == cpy_izquierdaAbajo){
			isMove = true;
				if(checador[1].color=="white"){
					ejecutarMovimiento( multiplier * -1, multiplier * -1, multiplier * -9);
					if(puedeAtacar) comprobar_eliminacion ( index  + 9) ;
				}
				else{
					ejecutarMovimiento( multiplier * -1, multiplier * 1, multiplier * 7);
					if(puedeAtacar) comprobar_eliminacion ( index  - 7) ;
				}
			}
		}

	borrarCamino(0);
	checador[piezaElegidaindex].checkIfKing();

	if (isMove) {
			playSound(moveSound);
			otro_movimiento = undefined;
		 if(puedeAtacar) {
			 	otro_movimiento = movimientos_DAtaque(checador[piezaElegidaindex]);
		 }
		if (otro_movimiento){
			primer_Movimiento = checador[piezaElegidaindex];
			mostrar_movimientos(primer_Movimiento);
		}
		else{
			primer_Movimiento = undefined;
		 	cambio_Dturnos(checador[1]);
		 	fin_de_juego = revisar_siPerdio();
		 	if(fin_de_juego) { setTimeout( declaraGanador(),3000 ); return false};
		 	fin_de_juego = revisarLosMovientos();
		 	if(fin_de_juego) { setTimeout( declaraGanador() ,3000) ; return false};
		}
	}
}

/*=====================================================================================================================================*/


function ejecutarMovimiento (X,Y,nSquare){
	checador[piezaElegidaindex].changeCoord(X,Y); 
	checador[piezaElegidaindex].setCoord(0,0);
	bloque[checador[piezaElegidaindex].ocupied_square].ocupied = false;			
	bloque[checador[piezaElegidaindex].ocupied_square + nSquare].ocupied = true;
	bloque[checador[piezaElegidaindex].ocupied_square + nSquare].pieceId = 	bloque[checador[piezaElegidaindex].ocupied_square ].pieceId;
	bloque[checador[piezaElegidaindex].ocupied_square ].pieceId = undefined; 	
	checador[piezaElegidaindex].ocupied_square += nSquare;

}

/*=====================================================================================================================================*/


function revisarMovimiento(Apiece,tLimit,tLimit_Side,moveDirection,theDirection){
	if(Apiece.coordY != tLimit){
		if(Apiece.coordX != tLimit_Side && !bloque[ Apiece.ocupied_square + moveDirection ].ocupied){
			bloque[ Apiece.ocupied_square + moveDirection ].id.style.background = "#82E0AA";
			theDirection = Apiece.ocupied_square + moveDirection;
		}
	else
			theDirection = undefined;
	}
	else
		theDirection = undefined;
	return theDirection;
}
function playSound(sound){
	if(sound) sound.play();
}
/*=====================================================================================================================================*/


function  revisar_elAtaque( check , X, Y , negX , negY, squareMove, direction){
	if(check.coordX * negX >= 	X * negX && check.coordY *negY <= Y * negY && bloque[check.ocupied_square + squareMove ].ocupied && bloque[check.ocupied_square + squareMove].pieceId.color != check.color && !bloque[check.ocupied_square + squareMove * 2 ].ocupied){
		puedeAtacar = true;
		direction = check.ocupied_square +  squareMove*2 ;
		bloque[direction].id.style.background = "#82E0AA";
		return direction ;
	}
	else
		direction =  undefined;
		return direction;
}

/*=====================================================================================================================================*/

function comprobar_eliminacion(indexx){
	if(indexx < 1 || indexx > 64)
		return  0;

	var x =bloque[ indexx ].pieceId ;
	x.alive =false;
	bloque[ indexx ].ocupied = false;
	x.id.style.display  = "none";
}

/*=====================================================================================================================================*/
 	
function movimientos_DAtaque(ckc){

 		derchaArriba = undefined;
 		izquierdaArriba = undefined;
 		derechaAbajo = undefined;
 		izquierdaAbajo = undefined;

 	if(ckc.king ){
 		if(ckc.color == "white"){
			derchaArriba = revisar_elAtaque( ckc , 6, 3 , -1 , -1 , -7, derchaArriba );
			izquierdaArriba = revisar_elAtaque( ckc, 3 , 3 , 1 , -1 , -9 , izquierdaArriba );
		}
		else{
	 		izquierdaAbajo = revisar_elAtaque( ckc , 3, 6, 1 , 1 , 7 , izquierdaAbajo );
			derechaAbajo = revisar_elAtaque( ckc , 6 , 6 , -1, 1 ,9 , derechaAbajo );		
		}
	}
	if(ckc.color == "white"){
	 	izquierdaAbajo = revisar_elAtaque( ckc , 3, 6, 1 , 1 , 7 , izquierdaAbajo );
		derechaAbajo = revisar_elAtaque( ckc , 6 , 6 , -1, 1 ,9 , derechaAbajo );
	}
	else{
		derchaArriba = revisar_elAtaque( ckc , 6, 3 , -1 , -1 , -7, derchaArriba );
		izquierdaArriba = revisar_elAtaque( ckc, 3 , 3 , 1 , -1 , -9 , izquierdaArriba );
	}
 	
 	if(ckc.color== "black" && (derchaArriba || izquierdaArriba || izquierdaAbajo || derechaAbajo ) ) {
	 	var p = izquierdaArriba;
	 	izquierdaArriba = izquierdaAbajo;
	 	izquierdaAbajo = p;

	 	p = derchaArriba;
	 	derchaArriba = derechaAbajo;
	 	derechaAbajo = p;

	 	p = izquierdaAbajo ;
	 	izquierdaAbajo = derechaAbajo;
	 	derechaAbajo = p;

	 	p = derchaArriba ;
	 	derchaArriba = izquierdaArriba;
	 	izquierdaArriba = p;
 	}
 	if(izquierdaArriba != undefined || derchaArriba != undefined || derechaAbajo != undefined || izquierdaAbajo != undefined){
 		return true;

 	}
 	return false;
}

/*=====================================================================================================================================*/

function cambio_Dturnos(ckc){
		if(ckc.color=="white")
	checador = revisar_FNegra;
else
	checador = revisar_FBlanco;
 }

/*=====================================================================================================================================*/

function revisar_siPerdio(){
	var i;
	for(i = 1 ; i <= 12; i++)
		if(checador[i].alive)
			return false;
	return true;
}

/*=====================================================================================================================================*/

function  revisarLosMovientos(){
	var i ;
	for(i = 1 ; i <= 12; i++)
		if(checador[i].alive && mostrar_movimientos(checador[i].id)){
			borrarCamino(0);
			return false;
		}
	return true;
}

/*=====================================================================================================================================*/

function declaraGanador(){
	playSound(winSound);
	fondo_Negro.style.display = "inline";
	Puntajes.style.display = "block";
0
if(checador[1].color == "white")
	Puntajes.innerHTML = "Ganan Fichas Negras";
else
	Puntajes.innerHTML = "Ganan Fichas Rojas";
}


function getDimension (){
	contor ++;
	windowHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight; 
	windowWidth =  window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
}

/*=====================================================================================================================================*/

document.getElementsByTagName("BODY")[0].onresize = function(){

	getDimension();
	var cpy_pantalla = pantalla ;

	if(windowWidth < 650){
		largoMovida = 50;
		desviacionMovida = 6; 
		if(pantalla == 1) pantalla = -1;
	}
	if(windowWidth > 650){
		largoMovida = 80;
		desviacionMovida = 10; 
		if(pantalla == -1) pantalla = 1;
	}

	if(pantalla !=cpy_pantalla){
		for(var i = 1; i <= 12; i++){
			revisar_FNegra[i].setCoord(0,0);
			revisar_FBlanco[i].setCoord(0,0);
		}
	}
}
/*=====================================================================================================================================*/
